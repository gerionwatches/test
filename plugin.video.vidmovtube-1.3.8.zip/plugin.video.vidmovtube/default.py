# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
import json
import re
import time
import requests
from urllib.parse import parse_qsl, urlencode, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import vidmov, player, catalog_cache, cast, play_history

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_PLUGIN = sys.argv[0]


def get_base() -> str:
    return vidmov.normalize_base(ADDON.getSetting("base_url") or "https://vm.beeteam368.net")


def plugin_url(**kwargs) -> str:
    return BASE_PLUGIN + "?" + urlencode({k: v for k, v in kwargs.items() if v is not None})


def add_dir(title, thumb="", context=None, **params):
    url = plugin_url(**params)
    li = xbmcgui.ListItem(label=title)
    li.setArt({"icon": thumb or "DefaultFolder.png", "thumb": thumb, "poster": thumb})
    li.addContextMenuItems((context or []) + refresh_context())
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def add_video(item: dict):
    title = item.get("title") or "Video"
    label = "[COLOR FF64B5F6]" + title + "[/COLOR]" if play_history.contains(item.get("url") or "") else title
    li = xbmcgui.ListItem(label=label)
    info = {"title": item.get("title"), "plot": item.get("plot") or ""}
    li.setInfo("video", info)
    set_cast(li, item.get("cast") or [])
    art = {}
    if item.get("thumb"):
        art["thumb"] = art["poster"] = art["fanart"] = item["thumb"]
    li.setArt(art)
    li.addContextMenuItems(favorite_context("video", item) + [("Reparto", "Container.Update(" + plugin_url(mode="cast", url=item.get("url") or "") + ")")] + [("Categorías", "Container.Update(" + plugin_url(mode="video_categories", url=item.get("url") or "") + ")")] + [("Volver al menú principal", "Container.Update(" + plugin_url(mode="root") + ",replace)")] + refresh_context())
    # A mirror picker is an action, not a pending playback request.
    li.setProperty("IsPlayable", "false")
    url = plugin_url(mode="choose", url=item.get("url") or "",
                     title=item.get("title") or "Video", plot=item.get("plot") or "",
                     thumb=item.get("thumb") or "")
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def end():
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def mode_root():
    add_dir("Últimos vídeos", mode="latest", page="1")
    add_dir("Categorías", mode="categories")
    add_dir("Favoritos", mode="favorites")
    add_dir("Stars", mode="stars")
    add_dir("Buscar", mode="search")
    add_dir("Ajustes (URL del sitio)", mode="settings")
    for index, shortcut in enumerate(load_shortcuts()):
        context = [(label, action_url(mode='shortcut_edit', operation=operation, index=index,
                                      title=shortcut['title'], path=shortcut['path']))
                   for label, operation in [('Editar categoría', 'edit'), ('Eliminar categoría', 'remove')]]
        add_dir(shortcut["title"], context=context, mode="latest", page="1", source="html", category_path=shortcut["path"])
    end()


def mode_latest(page: int = 1, search: str = "", tax: str = "", term: str = "",
                source: str = "", listing_url: str = "", previous: str = "", category_path: str = ""):
    base = get_base()
    if category_path.startswith("/stars/") and listing_url:
        origin = urlsplit(listing_url)
        base = origin.scheme + "://" + origin.netloc
    catalog_path = category_path
    if not category_path and not search and not tax and source != "rest":
        catalog_path = (ADDON.getSetting("catalog_path") or "/category/english-sub-7/").strip()
    use_json = not search and not catalog_path and source != "html" and ADDON.getSetting("use_wp_json") != "false"
    items, has_next, next_url = [], False, ""
    rest_loaded = False
    if use_json:
        try:
            cpt = vidmov.discover_cpt(base)
            items, has_next = vidmov.list_via_rest(
                base, cpt, page=page, search=search, tax=tax, term=int(term or 0), paginated=True)
            rest_loaded = True
            source = "rest"
        except Exception as exc:
            # A REST continuation must never switch back to the HTML homepage.
            if source == "rest":
                xbmcgui.Dialog().notification("VidMov Tube", "No se pudo cargar la siguiente página del catálogo.", xbmcgui.NOTIFICATION_ERROR)
                end()
                return
            xbmc.log("VidMov REST fallback: " + type(exc).__name__, xbmc.LOGWARNING)
    if not rest_loaded:
        if tax and not category_path:
            xbmcgui.Dialog().notification("VidMov Tube", "No se pudo cargar esta categoría. Vuelve al menú Categorías para actualizar su enlace.", xbmcgui.NOTIFICATION_ERROR)
            end()
            return
        source = "html"
        try:
            items, next_url = catalog_cache.fetch(vidmov.html_listing_page,
                base, page=page, search=search, tax=tax, term=term, listing_url=listing_url, catalog_path=catalog_path)
            has_next = bool(next_url)
        except Exception as exc:
            xbmcgui.Dialog().notification("VidMov Tube", playback_error_message(exc, "cargar el catálogo"), xbmcgui.NOTIFICATION_ERROR)
            end()
            return
    signature = vidmov.listing_signature(items)
    if previous and signature == previous:
        xbmcgui.Dialog().notification("VidMov Tube", "El sitio ha devuelto la misma página; no hay nuevos vídeos.", xbmcgui.NOTIFICATION_INFO)
        end()
        return
    for it in items:
        add_video(it)
    if items and has_next:
        add_dir("Página siguiente", mode="latest", page=str(page + 1), search=search,
                tax=tax, term=term, source=source, listing_url=next_url, previous=signature, category_path=category_path)
    end()


def mode_categories(page: int = 1, tax: str = "", previous: str = "", listing_url: str = ""):
    base = get_base()
    try:
        cats, next_url = catalog_cache.fetch(vidmov.list_categories_html,base, page=page, listing_url=listing_url)
    except Exception as exc:
        xbmcgui.Dialog().notification("VidMov Tube", playback_error_message(exc, "cargar las categorías"), xbmcgui.NOTIFICATION_ERROR)
        end()
        return
    signature = vidmov.category_signature(cats)
    if previous and signature == previous:
        xbmcgui.Dialog().notification("VidMov Tube", "El sitio ha devuelto las mismas categorías; no hay resultados nuevos.", xbmcgui.NOTIFICATION_INFO)
        end()
        return
    if not cats:
        message = "No se encontraron enlaces upk-category-item en /categories/" if page == 1 else "No hay más categorías."
        xbmcgui.Dialog().notification("VidMov Tube", message, xbmcgui.NOTIFICATION_INFO)
    for cat in cats:
        label = cat["title"]
        if cat.get("count"):
            label += f" ({cat['count']})"
        path = vidmov.category_archive_path(base, cat)
        add_dir(label, context=[("Añadir al menú principal", action_url(mode="shortcut_add", title=cat["title"], path=path))], mode="latest", page="1", tax=cat.get("tax") or "", term=str(cat.get("id") or ""),
                category_path=path, listing_url=cat.get("link") or "", source="html" if path else "")
    if cats and next_url:
        add_dir("Página siguiente", mode="categories", page=str(page + 1),
                listing_url=next_url, previous=signature)
    end()


def mode_stars(page=1, previous='', listing_url=''):
    try:
        stars, next_url = catalog_cache.fetch(vidmov.list_stars_html,get_base(), page=page, listing_url=listing_url)
    except Exception as exc:
        xbmcgui.Dialog().notification('VidMov Tube', playback_error_message(exc, 'cargar Stars'), xbmcgui.NOTIFICATION_ERROR)
        end()
        return
    signature = vidmov.category_signature(stars)
    if previous and signature == previous:
        xbmcgui.Dialog().notification('VidMov Tube', 'El sitio ha devuelto la misma página de Stars.', xbmcgui.NOTIFICATION_INFO)
        end()
        return
    for star in stars:
        label = star['title'] + (' (' + star['count'] + ')' if star.get('count') else '')
        add_dir(label, thumb=star.get("thumb") or "", context=favorite_context("star", dict(star, url=star["link"])), mode='latest', page='1', source='html',
                category_path=star['path'], listing_url=star['link'])
    if stars and next_url:
        add_dir('Página siguiente', mode='stars', page=str(page + 1),
                listing_url=next_url, previous=signature)
    if not stars:
        xbmcgui.Dialog().notification('VidMov Tube', 'No se encontraron Stars en esta página.', xbmcgui.NOTIFICATION_INFO)
    end()


def mode_search():
    kb = xbmc.Keyboard("", "Buscar en el tubo VidMov")
    kb.doModal()
    if not kb.isConfirmed():
        return
    q = kb.getText().strip()
    if q:
        mode_latest(page=1, search=q)


def playback_error_message(exc, stage):
    """Explain the failure without logging URLs, query tokens or cookies."""
    prefix = "Error al " + stage + ". "
    if isinstance(exc, vidmov.ArchiveRedirectError):
        return str(exc)
    if isinstance(exc, requests.exceptions.HTTPError):
        response = exc.response
        code = response.status_code if response is not None else None
        reasons = {
            401: "El servidor requiere autenticación.",
            403: "El servidor ha denegado el acceso.",
            404: "No se encuentra la página. El enlace puede ser incorrecto o haber caducado.",
            410: "La página ya no está disponible.",
            429: "El servidor limita las peticiones. Espera antes de reintentarlo.",
        }
        reason = reasons.get(code, "El servidor está fallando. Reintenta más tarde o prueba otro mirror." if code and code >= 500 else "El servidor devolvió un error.")
        return prefix + "HTTP " + str(code or "desconocido") + ": " + reason
    if isinstance(exc, requests.exceptions.SSLError):
        return prefix + "No se pudo verificar el certificado HTTPS del servidor."
    if isinstance(exc, requests.exceptions.Timeout):
        return prefix + "El servidor no respondió dentro del tiempo de espera. Reintenta o prueba otro mirror."
    if isinstance(exc, requests.exceptions.ConnectionError):
        return prefix + "No se pudo conectar con el servidor."
    if stage == "resolver el servidor de vídeo":
        return prefix + "El proveedor o su conector no pudo completar la resolución. Prueba otro mirror o actualiza ResolveURL."
    return prefix + "Fallo interno (" + type(exc).__name__ + "). Consulta el registro de Kodi."


def show_playback_error(exc, stage):
    message = str(exc) if isinstance(exc, player.PlaybackError) else playback_error_message(exc, stage)
    if not isinstance(exc, player.PlaybackError):
        xbmc.log("VidMov: " + message, xbmc.LOGWARNING)
    xbmcgui.Dialog().ok("VidMov Tube", message)


def mirror_labels(mirrors, original_url, original_html, cache=None):
    labels = [item['title'] + ' — Sin comprobar' for item in mirrors]
    if not mirrors:
        return labels
    providers = [''] * len(mirrors)
    statuses = ['Sin comprobar'] * len(mirrors)
    progress = xbmcgui.DialogProgress()
    support_context = {}
    finished = 0
    def on_result(index, entry):
        nonlocal finished
        if entry:
            if cache is not None:
                cache[mirrors[index]['url']] = entry
            status, host = player.source_support(entry['source'], entry['referer'], context=support_context)
            providers[index] = host[4:] if host.startswith('www.') else host
            statuses[index] = status
        finished += 1
        progress.update(int(finished * 100 / len(mirrors)), '{}/{} proveedores'.format(finished, len(mirrors)))
    try:
        progress.create('VidMov Tube', 'Comprobando proveedores… Cancelar para elegir ahora.')
        player.probe_mirrors(mirrors, original_url, original_html, progress.iscanceled, on_result)
    except Exception:
        # Inspection is advisory and must never prevent manual selection.
        pass
    finally:
        progress.close()
    for index, item in enumerate(mirrors):
        host = providers[index]
        name = host or item['title']
        if host and providers.count(host) > 1:
            name += ' (' + item['title'] + ')'
        status = statuses[index]
        item['support_status'] = status
        color = 'FF66CC66' if status in ('Conector disponible', 'Enlace directo', 'YouTube disponible') else 'FFFFD54F' if status in ('Sin conector directo', 'Falta ResolveURL', 'Falta YouTube') else 'FFFF6666'
        labels[index] = '[COLOR ' + color + ']' + name + ' — ' + status + '[/COLOR]'
    return labels


def mode_play(page_url: str, resolve_request=True, metadata=None):
    # Legacy playable URLs still use Kodi's resolver contract. New catalogue
    # actions start the player only after a source has actually been resolved.
    def finish_failure():
        if resolve_request:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

    if not page_url:
        finish_failure()
        return
    history_page_url = page_url
    stage = "cargar la ficha"
    try:
        original_url, original_html = player.load_page(page_url)
        stage = "leer la lista de mirrors"
        mirrors = player.parse_page(original_url, original_html).mirrors
    except Exception as exc:
        show_playback_error(exc, stage)
        finish_failure()
        return

    mirror_cache = {}
    labels = mirror_labels(mirrors, original_url, original_html, mirror_cache)
    if mirrors and ADDON.getSetting('hide_unsupported_mirrors') == 'true':
        visible = [(mirror, label) for mirror, label in zip(mirrors, labels)
                   if mirror.get('support_status') not in ('Sin conector directo', 'Falta ResolveURL', 'Falta YouTube')]
        if not visible:
            xbmcgui.Dialog().ok('VidMov Tube', 'Todos los mirrors están ocultos por el filtro. Desactiva «Ocultar mirrors sin conector» en Ajustes para mostrarlos.')
            finish_failure()
            return
        mirrors, labels = map(list, zip(*visible))
    while True:
        # Every attempt starts with the original page, never the last failed mirror.
        page_url, html = original_url, original_html
        if mirrors:
            selected = xbmcgui.Dialog().select(
                "Selecciona un mirror", labels)
            if selected < 0:
                finish_failure()
                return
        try:
            cached = None
            if mirrors:
                selected_url = mirrors[selected]["url"]
                cached = mirror_cache.pop(selected_url, None)
                if cached and time.monotonic() - cached['created'] > 300:
                    cached = None
            if cached:
                if cached.get('cookies') is not None:
                    vidmov.SESSION.cookies.update(cached['cookies'])
                source, page_url = cached['source'], cached['referer']
            else:
                if mirrors and selected_url != original_url:
                    stage = "cargar el mirror seleccionado"
                    page_url, html = player.load_page(selected_url, original_url)
                stage = "leer la configuración del reproductor"
                source = player.extract_source(page_url, html)
            if not source:
                raise player.PlaybackError(
                    "Este mirror no expone una URL en el HTML ni en la configuración "
                    "del reproductor. Prueba otro mirror.")
            stage = "resolver el servidor de vídeo"
            play = player.resolve_source(source, page_url)
            if play.startswith('plugin://plugin.video.youtube/') and not xbmc.getCondVisibility(
                    'System.HasAddon(plugin.video.youtube)'):
                raise player.PlaybackError('Instala el complemento YouTube para reproducir este enlace.')
        except Exception as exc:
            show_playback_error(exc, stage)
            if mirrors:
                # Keep the picker open so another mirror can be selected.
                continue
            finish_failure()
            return
        playback_observer = play_history.observe(play)
        li = xbmcgui.ListItem(path=play)
        li.setProperty("IsPlayable", "true")
        if resolve_request:
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            info = metadata or {}
            li.setInfo("video", {"title": info.get("title") or "Video",
                                 "plot": info.get("plot") or ""})
            if info.get("thumb"):
                li.setArt({key: info["thumb"] for key in ("thumb", "poster", "fanart")})
            xbmc.Player().play(play, li)
        if play_history.wait_for_start(playback_observer, history_page_url):
            xbmc.executebuiltin("Container.Refresh")
        return


def shortcut_path(value):
    value = value.strip()
    parts = urlsplit(value)
    if parts.netloc:
        if parts.scheme not in ('http', 'https') or parts.netloc != urlsplit(get_base()).netloc:
            raise ValueError('Usa una categoría del sitio configurado.')
        value = parts.path
    elif not value.startswith('/'):
        value = '/category/' + value
    if parts.query or parts.fragment or not re.fullmatch(r'/category/[^/\s?#]+/?', value):
        raise ValueError('Introduce /category/nombre/ o solo el nombre de la ruta.')
    return value.rstrip('/') + '/'


def load_shortcuts():
    try:
        entries = json.loads(ADDON.getSetting('category_shortcuts') or '[]')
    except (ValueError, TypeError):
        return []
    if not isinstance(entries, list):
        return []
    result = []
    for item in entries:
        try:
            if isinstance(item, dict) and isinstance(item.get('title'), str) and item['title'].strip():
                result.append({'title': item['title'].strip(), 'path': shortcut_path(item['path'])})
        except (KeyError, ValueError, TypeError, AttributeError):
            continue
    return result


def mode_shortcut_edit(params):
    entries = load_shortcuts()
    try:
        index = int(params.get('index', '-1'))
    except ValueError:
        return
    if not 0 <= index < len(entries):
        return
    old = entries[index]
    # A stale context menu must not edit a different entry after reordering.
    if old['path'] != params.get('path') or old['title'] != params.get('title'):
        xbmc.executebuiltin('Container.Refresh')
        return
    if params.get('operation') == 'remove':
        del entries[index]
    elif params.get('operation') == 'edit':
        dialog = xbmcgui.Dialog()
        title = dialog.input('Nombre en el menú', old['title']).strip()
        if not title:
            return
        value = dialog.input('Ruta de categoría: /category/nombre/', old['path']).strip()
        if not value:
            return
        try:
            path = shortcut_path(value)
        except ValueError as exc:
            dialog.ok('VidMov Tube', str(exc))
            return
        entries[index] = {'title': title, 'path': path}
    else:
        return
    ADDON.setSetting('category_shortcuts', json.dumps(entries, ensure_ascii=False))
    xbmc.executebuiltin('Container.Refresh')


def mode_shortcuts():
    entries = load_shortcuts()
    changed = False
    dialog = xbmcgui.Dialog()
    while True:
        selected = dialog.select('Categorías del menú inicial', ['Añadir categoría'] + [item['title'] for item in entries])
        if selected < 0:
            break
        index = selected - 1
        if selected:
            action = dialog.select(entries[index]['title'], ['Editar', 'Eliminar', 'Mover arriba', 'Mover abajo'])
            if action < 0:
                continue
            if action in (2, 3):
                target = index + (-1 if action == 2 else 1)
                if 0 <= target < len(entries):
                    entries[index], entries[target] = entries[target], entries[index]
                    ADDON.setSetting('category_shortcuts', json.dumps(entries, ensure_ascii=False))
                    changed = True
                continue
            if action == 1:
                del entries[index]
                ADDON.setSetting('category_shortcuts', json.dumps(entries, ensure_ascii=False))
                changed = True
                continue
        old = entries[index] if selected else {'title': '', 'path': ''}
        title = dialog.input('Nombre en el menú', old['title']).strip()
        if not title:
            continue
        value = dialog.input('Ruta de categoría: /category/nombre/', old['path']).strip()
        if not value:
            continue
        try:
            path = shortcut_path(value)
        except ValueError as exc:
            dialog.ok('VidMov Tube', str(exc))
            continue
        item = {'title': title, 'path': path}
        if selected:
            entries[index] = item
        else:
            entries.append(item)
        ADDON.setSetting('category_shortcuts', json.dumps(entries, ensure_ascii=False))
        changed = True
    if changed:
        xbmc.executebuiltin('Container.Refresh')


def action_url(**params):
    return 'RunPlugin(' + plugin_url(**params) + ')'


def refresh_context():
    return [('Actualizar catálogo', action_url(mode='refresh'))]


def load_favorites():
    try:
        items = json.loads(ADDON.getSetting('favorites') or '[]')
        return [item for item in items if isinstance(item, dict) and item.get('kind') in ('video', 'star')
                and isinstance(item.get('url'), str) and urlsplit(item['url']).scheme in ('http', 'https')] if isinstance(items, list) else []
    except (ValueError, TypeError):
        return []


def favorite_context(kind, item):
    url = item.get('url') or ''
    exists = any(f['kind'] == kind and f['url'].rstrip('/') == url.rstrip('/') for f in load_favorites())
    return [('Quitar de favoritos' if exists else 'Añadir a favoritos', action_url(
        mode='favorite_edit', operation='remove' if exists else 'add', kind=kind, url=url,
        title=item.get('title') or '', thumb=item.get('thumb') or '', plot=item.get('plot') or ''))]


def mode_favorite_edit(params):
    kind, url = params.get('kind'), params.get('url') or ''
    if kind not in ('video', 'star') or urlsplit(url).scheme not in ('http', 'https'):
        return
    entries = [f for f in load_favorites() if not (f['kind'] == kind and f['url'].rstrip('/') == url.rstrip('/'))]
    if params.get('operation') == 'add':
        entries.append({key: params.get(key) or '' for key in ('kind', 'url', 'title', 'thumb', 'plot')})
    ADDON.setSetting('favorites', json.dumps(entries, ensure_ascii=False))
    xbmc.executebuiltin('Container.Refresh')


def mode_favorites(kind=''):
    if kind not in ('video', 'star'):
        add_dir('Vídeos favoritos', mode='favorites', kind='video')
        add_dir('Stars favoritas', mode='favorites', kind='star')
    else:
        entries = [item for item in load_favorites() if item['kind'] == kind]
        for item in entries:
            if item['kind'] != kind:
                continue
            if kind == 'video':
                add_video(item)
            else:
                add_dir(item.get('title') or 'Star', thumb=item.get('thumb') or '',
                        context=favorite_context('star', item), mode='favorite_star', url=item['url'])
    end()


def mode_favorite_star(url):
    # Use the favorite's original site even if the configured site later changes.
    parts = urlsplit(url)
    if parts.scheme not in ('http', 'https') or not re.fullmatch(r'/stars/[^/]+/?', parts.path):
        end()
        return
    mode_latest(source='html', category_path=parts.path, listing_url=url)


def mode_shortcut_add(title, path):
    try:
        path = shortcut_path(path)
    except ValueError as exc:
        xbmcgui.Dialog().ok('VidMov Tube', str(exc))
        return
    entries = load_shortcuts()
    if not any(item['path'] == path for item in entries):
        entries.append({'title': title or path, 'path': path})
        ADDON.setSetting('category_shortcuts', json.dumps(entries, ensure_ascii=False))
    xbmcgui.Dialog().notification('VidMov Tube', 'Categoría disponible en el menú principal.', xbmcgui.NOTIFICATION_INFO)


def mode_refresh():
    catalog_cache.clear()
    xbmc.executebuiltin('Container.Refresh')


def set_cast(listitem, actors):
    if not actors:
        return
    if hasattr(xbmc, 'Actor'):
        listitem.getVideoInfoTag().setCast([
            xbmc.Actor(name=actor['name'], role='', order=index,
                       thumbnail=actor.get('thumbnail') or '')
            for index, actor in enumerate(actors)])
    else:
        listitem.setCast([{'name': actor['name'], 'thumbnail': actor.get('thumbnail') or '',
                           'order': index} for index, actor in enumerate(actors)])


def mode_cast(url):
    try:
        actors = catalog_cache.fetch(cast.load, url)
    except Exception as exc:
        xbmcgui.Dialog().notification('VidMov Tube', playback_error_message(exc, 'cargar el reparto'), xbmcgui.NOTIFICATION_ERROR)
        end()
        return
    for actor in actors:
        item = {'title': actor['name'], 'url': actor['url'], 'thumb': actor['thumbnail']}
        add_dir(actor['name'], thumb=actor['thumbnail'], context=favorite_context('star', item),
                mode='favorite_star', url=actor['url'])
    if not actors:
        xbmcgui.Dialog().notification('VidMov Tube', 'La ficha no incluye reparto reconocible.', xbmcgui.NOTIFICATION_INFO)
    end()


def mode_video_categories(url):
    try:
        categories = catalog_cache.fetch(vidmov.load_video_categories, url)
    except Exception as exc:
        xbmcgui.Dialog().notification('VidMov Tube', playback_error_message(exc, 'cargar las categorías del vídeo'), xbmcgui.NOTIFICATION_ERROR)
        end()
        return
    for category in categories:
        add_dir(category['title'], mode='latest', page='1', source='html',
                category_path=category['path'], listing_url=category['link'],
                context=[('Añadir al menú principal', action_url(mode='shortcut_add',
                         title=category['title'], path=category['path']))])
    if not categories:
        xbmcgui.Dialog().notification('VidMov Tube', 'La ficha no incluye categorías reconocibles.', xbmcgui.NOTIFICATION_INFO)
    end()


def mode_settings():
    ADDON.openSettings()


def router():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode = params.get("mode") or "root"
    if mode == "root":
        mode_root()
    elif mode == "latest":
        mode_latest(page=int(params.get("page") or 1), search=params.get("search") or "", tax=params.get("tax") or "", term=params.get("term") or "", source=params.get("source") or "", listing_url=params.get("listing_url") or "", previous=params.get("previous") or "", category_path=params.get("category_path") or "")
    elif mode == "categories":
        mode_categories(page=int(params.get("page") or 1), previous=params.get("previous") or "", listing_url=params.get("listing_url") or "")
    elif mode == "stars":
        mode_stars(page=int(params.get("page") or 1), previous=params.get("previous") or "", listing_url=params.get("listing_url") or "")
    elif mode == "search":
        mode_search()
    elif mode == "choose":
        mode_play(params.get("url") or "", resolve_request=False, metadata=params)
    elif mode == "play":
        mode_play(params.get("url") or "")
    elif mode == "video_categories":
        mode_video_categories(params.get("url") or "")
    elif mode == "cast":
        mode_cast(params.get("url") or "")
    elif mode == "favorites":
        mode_favorites(params.get('kind') or '')
    elif mode == "favorite_edit":
        mode_favorite_edit(params)
    elif mode == "favorite_star":
        mode_favorite_star(params.get('url') or '')
    elif mode == "shortcut_add":
        mode_shortcut_add(params.get('title') or '', params.get('path') or '')
    elif mode == "refresh":
        mode_refresh()
    elif mode == "shortcut_edit":
        mode_shortcut_edit(params)
    elif mode == "shortcuts":
        mode_shortcuts()
    elif mode == "clear_play_history":
        try:
            play_history.clear()
            xbmc.executebuiltin("Container.Refresh")
            xbmcgui.Dialog().notification("VidMov Tube", "Registro de reproducciones borrado.", xbmcgui.NOTIFICATION_INFO)
        except Exception:
            xbmcgui.Dialog().ok("VidMov Tube", "No se pudo borrar el registro. Inténtalo de nuevo.")
    elif mode == "settings":
        mode_settings()
    else:
        mode_root()


if __name__ == "__main__":
    import xbmcvfs
    from resources.lib import initial_settings
    try:
        initial_settings.initialize(ADDON, xbmcvfs)
    except Exception as exc:
        xbmc.log("VidMov initial settings: " + type(exc).__name__, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("VidMov Tube", "No se pudo aplicar la configuración inicial. Revisa resources/default-settings.xml.", xbmcgui.NOTIFICATION_ERROR)
    catalog_cache.configure(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
    play_history.configure(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
    router()
