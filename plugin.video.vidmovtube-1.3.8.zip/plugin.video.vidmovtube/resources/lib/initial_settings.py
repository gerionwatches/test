"""Apply the bundled generic preset only when no profile settings exist."""
import json
import xml.etree.ElementTree as ET

ALLOWED = {'base_url', 'catalog_path', 'category_shortcuts', 'favorites', 'hide_unsupported_mirrors'}


def initialize(addon, vfs):
    profile = addon.getAddonInfo('profile').rstrip('/\\') + '/settings.xml'
    if vfs.exists(profile):
        return False
    source = addon.getAddonInfo('path').rstrip('/\\') + '/resources/default-settings.xml'
    stream = vfs.File(source)
    try:
        root = ET.fromstring(stream.read())
    finally:
        stream.close()
    if root.tag != 'settings':
        raise ValueError('Invalid initial settings document')
    values = {}
    for entry in root.findall('setting'):
        key = entry.get('id')
        if key not in ALLOWED:
            continue
        value = entry.get('value') if entry.get('value') is not None else (entry.text or '')
        if key in ('category_shortcuts', 'favorites') and not isinstance(json.loads(value), list):
            raise ValueError('Expected a JSON list')
        if key == 'hide_unsupported_mirrors' and value not in ('true', 'false'):
            raise ValueError('Expected true or false')
        values[key] = value
    # Validate the whole preset before saving any of its settings.
    for key, value in values.items():
        addon.setSetting(key, value)
    return True
