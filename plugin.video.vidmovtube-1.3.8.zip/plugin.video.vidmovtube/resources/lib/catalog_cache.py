"""Small expiring cache of parsed listings only; never stores playback URLs."""
import hashlib
import json
import os
import tempfile
import time
from pathlib import Path

DIRECTORY = None
TTL = 600
LIMIT = 150


def configure(profile):
    global DIRECTORY
    DIRECTORY = Path(profile) / 'catalog_cache_v2'


def clear():
    if DIRECTORY is not None and DIRECTORY.exists():
        for path in DIRECTORY.glob('*.json'):
            try:
                path.unlink()
            except OSError:
                pass


def fetch(function, *args, **kwargs):
    if DIRECTORY is None:
        return function(*args, **kwargs)
    key = json.dumps([function.__name__, args, kwargs], sort_keys=True, ensure_ascii=False)
    path = DIRECTORY / (hashlib.sha256(key.encode('utf-8')).hexdigest() + '.json')
    try:
        entry = json.loads(path.read_text(encoding='utf-8'))
        if 0 <= time.time() - entry['created'] < TTL:
            return entry['value']
    except (OSError, ValueError, KeyError, TypeError):
        pass
    value = function(*args, **kwargs)
    temporary = None
    try:
        DIRECTORY.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=str(DIRECTORY), suffix='.tmp', delete=False) as stream:
            temporary = stream.name
            json.dump({'created': time.time(), 'value': value}, stream, ensure_ascii=False)
        os.replace(temporary, path)
        files = sorted(DIRECTORY.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[LIMIT:]:
            old.unlink()
    except (OSError, TypeError, ValueError):
        pass
    finally:
        if temporary and os.path.exists(temporary):
            try:
                os.unlink(temporary)
            except OSError:
                pass
    return value
