"""Cast metadata from the video page; no player scripts are executed."""
from html.parser import HTMLParser
import requests
from . import vidmov


class CastParser(HTMLParser):
    def __init__(self, url):
        super().__init__(convert_charrefs=True)
        self.stars = vidmov.StarsPageParser(url)
        self.stack = []

    def handle_starttag(self, tag, attrs):
        classes = dict(attrs).get('class', '').split()
        active = any(self.stack) or 'cast-variant-items-wrapper' in classes or 'cast-variant-item' in classes
        if tag not in vidmov.ListingParser.VOID:
            self.stack.append(active)
        if active:
            self.stars.handle_starttag(tag, attrs)

    def handle_data(self, data):
        if any(self.stack):
            self.stars.handle_data(data)

    def handle_endtag(self, tag):
        if any(self.stack):
            self.stars.handle_endtag(tag)
        if tag not in vidmov.ListingParser.VOID and self.stack:
            self.stack.pop()

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in vidmov.ListingParser.VOID:
            self.handle_endtag(tag)


def parse(url, html):
    parser = CastParser(url)
    parser.feed(html)
    return [{'name': item['title'], 'thumbnail': item.get('thumb') or '',
             'url': item['link'], 'order': index}
            for index, item in enumerate(parser.stars.entries.values())]


def load(url):
    # Isolated session: metadata requests can run concurrently.
    with requests.Session() as session:
        session.headers.update(vidmov.SESSION.headers)
        session.cookies.update(vidmov.SESSION.cookies)
        response = session.get(url, timeout=(5, 8))
        response.raise_for_status()
        return parse(response.url, response.text)
