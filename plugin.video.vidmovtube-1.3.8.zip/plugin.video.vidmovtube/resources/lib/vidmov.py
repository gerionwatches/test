# -*- coding: utf-8 -*-
"""Parser for WordPress + VidMov (BeeTeam368) public HTML / REST."""
from __future__ import annotations

import json
import hashlib
from html.parser import HTMLParser
import re
from html import unescape
from urllib.parse import urljoin, urlparse, quote_plus, urlencode, parse_qsl, urlsplit, urlunsplit, quote

import requests

HEADERS = {
    "User-Agent": "VidMovTubeKodi/1.0 (didactic; SFW)",
    "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)
TIMEOUT = 20

CPT_CANDIDATES = ("vidmov_video", "video", "posts")
TAX_CANDIDATES = ("categories", "vidmov_video_category", "video-category", "video_category")


class ArchiveRedirectError(ValueError):
    pass


def _get(url: str) -> requests.Response:
    r = SESSION.get(url, timeout=TIMEOUT)
    r.raise_for_status()
    return r


def normalize_base(url: str) -> str:
    url = (url or "").strip().rstrip("/")
    if not url:
        return "https://vm.beeteam368.net"
    if not url.startswith("http"):
        url = "https://" + url
    return url


def abs_url(base: str, href: str) -> str:
    if not href:
        return ""
    return urljoin(base + "/", href)


def discover_cpt(base: str) -> str:
    try:
        types = _get(base + "/wp-json/wp/v2/types").json()
        if isinstance(types, dict):
            for key in CPT_CANDIDATES:
                if key in types:
                    return key
            for key, meta in types.items():
                rest = (meta or {}).get("rest_base") or key
                if "video" in key or "video" in rest:
                    return rest
    except Exception:
        pass
    return "vidmov_video"


def list_via_rest(base: str, cpt: str, page: int = 1, search: str = "", tax: str = "", term: int = 0, paginated=False):
    endpoint = f"{base}/wp-json/wp/v2/{cpt}"
    params = f"?per_page=20&page={page}&_embed=1"
    if search:
        params += "&search=" + quote_plus(search)
    if tax and term:
        params += f"&{tax}={term}"
    response = _get(endpoint + params)
    data = response.json()
    items = []
    if not isinstance(data, list):
        raise ValueError("La API no devolvió un catálogo")
    for post in data:
        title = unescape(post.get("title", {}).get("rendered") or post.get("slug") or "Video")
        title = re.sub(r"<[^>]+>", "", title)
        link = post.get("link") or ""
        thumb = ""
        emb = post.get("_embedded") or {}
        media = emb.get("wp:featuredmedia") or []
        if media:
            thumb = media[0].get("source_url") or ""
        items.append(
            {
                "title": title,
                "url": link,
                "thumb": thumb,
                "plot": re.sub(r"<[^>]+>", "", unescape(post.get("excerpt", {}).get("rendered") or "")),
                "id": post.get("id"),
            }
        )
    if paginated:
        total = response.headers.get('X-WP-TotalPages')
        has_next = page < int(total) if total and total.isdigit() else len(items) == 20
        return items, bool(items) and has_next
    return items



def list_categories_rest(base: str, page=1, tax='', paginated=False):
    # Discover the taxonomy once; subsequent pages must use the same endpoint.
    candidates = (tax,) if tax else TAX_CANDIDATES
    for candidate in candidates:
        try:
            response = _get(f"{base}/wp-json/wp/v2/{candidate}?per_page=50&page={page}&orderby=name&order=asc")
            data = response.json()
            if not isinstance(data, list):
                raise ValueError("La API no devolvió una lista de categorías")
            if not data and not tax:
                continue
            out = []
            for term in data:
                out.append({
                    "title": unescape(term.get("name") or term.get("slug") or "Categoría"),
                    "tax": candidate,
                    "id": term.get("id"),
                    "slug": term.get("slug"),
                    "link": term.get("link") or "",
                    "count": term.get("count") or 0,
                })
            total = response.headers.get('X-WP-TotalPages')
            has_next = page < int(total) if total and total.isdigit() else len(out) == 50
            return (out, bool(out) and has_next, candidate) if paginated else out
        except requests.exceptions.HTTPError as exc:
            if tax:
                if page > 1 and exc.response is not None and exc.response.status_code == 400:
                    try:
                        code = exc.response.json().get('code')
                    except (ValueError, AttributeError):
                        code = None
                    if code == 'rest_post_invalid_page_number':
                        return ([], False, tax) if paginated else []
                raise
        except Exception:
            if tax:
                raise
    return ([], False, '') if paginated else []


class CategoryPageParser(HTMLParser):
    def __init__(self, page_url):
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.items = []
        self.current = None
        self.spans = []
        self.seen = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get('class') or '').split()
        if tag == 'a':
            self.current = None
            self.spans = []
            if 'upk-category-item' in classes and attrs.get('href'):
                url = urljoin(self.page_url, attrs['href'])
                parts = urlsplit(url)
                if parts.scheme in ('http', 'https') and parts.netloc == urlsplit(self.page_url).netloc and parts.path.startswith('/category/'):
                    self.current = {'title': '', 'count': '', 'link': url, 'slug': parts.path.rstrip('/').split('/')[-1]}
        if tag == 'span' and self.current is not None:
            field = 'title' if 'upk-category-name' in classes else 'count' if 'upk-category-count' in classes else None
            self.spans.append(field)

    def handle_data(self, data):
        if self.current is not None:
            for field in reversed(self.spans):
                if field:
                    self.current[field] += data
                    break

    def handle_endtag(self, tag):
        if tag == 'span' and self.spans:
            self.spans.pop()
        if tag == 'a' and self.current is not None:
            item, self.current = self.current, None
            item['title'] = ' '.join(item['title'].split()) or item['slug']
            item['count'] = ' '.join(item['count'].split())
            key = item['link'].rstrip('/')
            if key not in self.seen:
                self.seen.add(key)
                self.items.append(item)
            self.spans = []


def list_categories_html(base, page=1, listing_url=''):
    url = listing_url or base.rstrip('/') + '/categories/'
    response = _get(url)
    categories = CategoryPageParser(response.url)
    categories.feed(response.text)
    pagination = PaginationParser(response.url, page)
    pagination.feed(response.text)
    # Read every category on this page; do not impose the REST API's 50-item limit.
    next_url = pagination.next_url or pagination.numbered_url
    return categories.items, next_url if categories.items else ''


class StarsPageParser(HTMLParser):
    """Read same-site star links, including image and text duplicates."""
    def __init__(self, page_url):
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.entries = {}
        self.current = None
        self.spans = []
        self.article = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'article':
            self.article = {'thumb': ''}
        if tag == 'img':
            src = attrs.get('data-src') or attrs.get('data-lazy-src') or attrs.get('src') or ''
            image = urljoin(self.page_url, src) if src and not src.startswith('data:') else ''
            if urlsplit(image).scheme not in ('http', 'https'):
                image = ''
            if self.article is not None and image:
                self.article['thumb'] = image
            if self.current is not None and image:
                self.current['thumb'] = image
        if tag == 'a':
            self.current = None
            self.spans = []
            parts = urlsplit(urljoin(self.page_url, attrs.get('href') or ''))
            if (parts.scheme in ('http', 'https') and parts.netloc == urlsplit(self.page_url).netloc
                    and re.fullmatch(r'/stars/[^/]+/?', parts.path)
                    and parts.path.rstrip('/') != '/stars/page'
                    and not parts.query and not parts.fragment):
                self.current = {'link': urlunsplit((parts.scheme, parts.netloc, parts.path.rstrip('/')+'/', '', '')),
                                'title': '', 'count': '', 'text': '', 'thumb': '', 'article': self.article, 'fallback': attrs.get('title') or '',
                                'path': parts.path.rstrip('/') + '/'}
        if self.current is not None:
            if tag == 'img' and not self.current['fallback']:
                self.current['fallback'] = attrs.get('alt') or ''
            if tag == 'span':
                classes = (attrs.get('class') or '').split()
                field = 'count' if any(c.endswith('-count') for c in classes) else 'title' if any(c.endswith('-name') for c in classes) else None
                self.spans.append(field)

    def handle_data(self, data):
        if self.current is not None:
            field = next((f for f in reversed(self.spans) if f), None)
            if field:
                self.current[field] += data
            if field != 'count':
                self.current['text'] += data

    def handle_endtag(self, tag):
        if tag == 'article':
            self.article = None
        if tag == 'span' and self.spans:
            self.spans.pop()
        if tag == 'a' and self.current is not None:
            item, self.current = self.current, None
            title = ' '.join((item['title'] or item['text'] or item['fallback']).split())
            item['thumb'] = item['thumb'] or (item['article'] or {}).get('thumb', '')
            old = self.entries.get(item['link'])
            item['thumb'] = item['thumb'] or (old or {}).get('thumb', '')
            if old is None or title:
                item['title'] = title or item['path'].strip('/').split('/')[-1].replace('-', ' ')
                item['count'] = ' '.join(item['count'].split()) or (old or {}).get('count', '')
                self.entries[item['link']] = item
            elif item['thumb']:
                old['thumb'] = item['thumb']


def list_stars_html(base, page=1, listing_url=''):
    url = listing_url or base.rstrip('/') + '/stars/' + ('page/{}/'.format(page) if page > 1 else '')
    try:
        response = _get(url)
    except requests.exceptions.HTTPError as exc:
        if page > 1 and exc.response is not None and exc.response.status_code in (404, 410):
            return [], ''
        raise
    parser = StarsPageParser(response.url)
    parser.feed(response.text)
    items = list(parser.entries.values())
    pagination = PaginationParser(response.url, page)
    pagination.feed(response.text)
    next_url = pagination.next_url or pagination.numbered_url
    if items and not next_url and pagination.load_more:
        next_url = base.rstrip('/') + '/stars/page/{}/'.format(page + 1)
    return items, next_url if items else ''


class VideoCategoriesParser(HTMLParser):
    """Only category links in the video's top metadata, not recommendations."""
    def __init__(self, url):
        super().__init__(convert_charrefs=True)
        self.url = url
        self.stack = []
        self.current = None
        self.items = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get('class') or '').split()
        active = any(value for _, value in self.stack) or 'top-post-meta' in classes
        if tag not in ListingParser.VOID:
            self.stack.append((tag, active))
        if tag == 'a':
            self.current = None
            if not active or 'category-item' not in classes or not attrs.get('href'):
                return
            parts = urlsplit(urljoin(self.url, attrs['href']))
            if (parts.scheme in ('http', 'https') and parts.netloc == urlsplit(self.url).netloc
                    and re.fullmatch(r'/category/[^/]+/?', parts.path) and not parts.query and not parts.fragment):
                path = parts.path.rstrip('/') + '/'
                self.current = {'title': '', 'fallback': attrs.get('title') or '', 'path': path,
                                'link': urlunsplit((parts.scheme, parts.netloc, path, '', ''))}

    def handle_data(self, data):
        if self.current is not None:
            self.current['title'] += data

    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            item, self.current = self.current, None
            item['title'] = ' '.join(item['title'].split()) or item['fallback'] or item['path'].strip('/').split('/')[-1]
            self.items.setdefault(item['link'], item)
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break


def load_video_categories(url):
    response = _get(url)
    parser = VideoCategoriesParser(response.url)
    parser.feed(response.text)
    return list(parser.items.values())


def category_archive_path(base, category):
    link = urlsplit(urljoin(base.rstrip('/') + '/', category.get('link') or ''))
    if category.get('link') and link.netloc == urlsplit(base).netloc and link.path.startswith('/category/') and not link.query:
        return link.path.rstrip('/') + '/'
    slug = category.get('slug') or ''
    return '/category/' + quote(slug, safe='%-_') + '/' if slug else ''


def category_signature(items):
    keys = sorted(item.get('link') or (str(item.get('tax')) + ':' + str(item.get('id'))) for item in items)
    return hashlib.sha256('\n'.join(keys).encode('utf-8')).hexdigest()


class ListingParser(HTMLParser):
    """Read video cards without size limits or assumptions about attribute order."""
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self, base):
        super().__init__(convert_charrefs=True)
        self.base = base
        self.stack = []
        self.article = None
        self.anchor = None
        self.entries = []
        self.has_main = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get('class') or '').split()
        blocked = tag in ('nav', 'aside', 'footer') or (tag == 'header' and self.article is None) or any(c in ('sidebar', 'widget', 'widget-area', 'widget-container') for c in classes)
        if tag == 'main':
            self.has_main = True
        if tag not in self.VOID:
            self.stack.append((tag, blocked))
        if tag == 'article':
            self.article = {'thumb': ''}
        if tag == 'img' and self.article is not None and not self.article['thumb']:
            src = attrs.get('data-src') or attrs.get('data-lazy-src') or attrs.get('src') or ''
            if src and not src.startswith('data:'):
                self.article['thumb'] = urljoin(self.base.rstrip('/') + '/', src)
        if tag == 'a':
            self.anchor = None
            href = attrs.get('href') or ''
            url = urljoin(self.base.rstrip('/') + '/', href)
            parts = urlsplit(url)
            if (parts.scheme not in ('http', 'https') or parts.netloc != urlsplit(self.base).netloc
                    or not re.fullmatch(r'/video/[^/]+/?', parts.path)
                    or parts.query or parts.fragment or any(block for _, block in self.stack)):
                return
            self.anchor = {'url': url, 'text': '', 'title': attrs.get('title') or '',
                           'preferred': 'post-listing-title' in classes or any(t in ('h2', 'h3', 'h4') for t, _ in self.stack),
                           'main': any(t == 'main' for t, _ in self.stack), 'article': self.article}

    def handle_data(self, data):
        if self.anchor is not None:
            self.anchor['text'] += data

    def handle_endtag(self, tag):
        if tag == 'a' and self.anchor is not None:
            self.entries.append(self.anchor)
            self.anchor = None
        if tag == 'article':
            self.article = None
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)


def parse_listing_html(base: str, html: str):
    parser = ListingParser(base)
    parser.feed(html)
    items, scores = {}, {}
    for entry in parser.entries:
        if parser.has_main and not entry['main']:
            continue
        text = ' '.join(entry['text'].split()) or entry['title'].strip()
        key = entry['url'].rstrip('/')
        score = (2 if entry['preferred'] else 0) + bool(text)
        thumb = (entry['article'] or {}).get('thumb', '')
        if key not in items:
            items[key] = {'title': text or urlsplit(entry['url']).path.strip('/').split('/')[-1],
                          'url': entry['url'], 'thumb': thumb, 'plot': ''}
            scores[key] = score
        else:
            if score > scores[key] and text:
                items[key]['title'] = text
                scores[key] = score
            if thumb and not items[key]['thumb']:
                items[key]['thumb'] = thumb
    return list(items.values())


def list_via_html(base: str, path: str = "/"):
    html = _get(abs_url(base, path)).text
    return parse_listing_html(base, html)


def listing_signature(items):
    urls = sorted(set(item.get('url', '') for item in items))
    return hashlib.sha256('\n'.join(urls).encode('utf-8')).hexdigest()


class PaginationParser(HTMLParser):
    def __init__(self, current_url, page):
        super().__init__(convert_charrefs=True)
        self.current_url = current_url
        self.page = page
        self.next_url = ''
        self.numbered_url = ''
        self.load_more = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get('class') or '').split()
        if any('loadmore' in c or 'load-more' in c for c in classes):
            self.load_more = True
        href = attrs.get('href')
        if tag not in ('a', 'link') or not href:
            return
        target = urljoin(self.current_url, href)
        parts = urlsplit(target)
        if parts.scheme not in ('http', 'https') or parts.netloc != urlsplit(self.current_url).netloc:
            return
        if target == self.current_url or href.startswith('#'):
            return
        if 'next' in (attrs.get('rel') or '').split() or ('next' in classes and 'page-numbers' in classes):
            self.next_url = target
        if 'page-numbers' in classes:
            match = re.search(r'/page/(\d+)/?', parts.path)
            number = (match.group(1) if match else dict(parse_qsl(parts.query)).get('paged', ''))
            if number == str(self.page + 1):
                self.numbered_url = target


def html_listing_page(base, page=1, search='', tax='', term='', listing_url='', catalog_path=''):
    query = {}
    if search:
        query['s'] = search
    if tax and term and not catalog_path:
        query[tax] = term
    root_path = '/' + catalog_path.strip('/') + '/' if catalog_path.strip('/') else '/'
    path = root_path if page == 1 else root_path + 'page/{}/'.format(page)
    url = listing_url or base.rstrip('/') + path + ('?' + urlencode(query) if query else '')
    try:
        response = _get(url)
    except requests.exceptions.HTTPError as exc:
        if page > 1 and exc.response is not None and exc.response.status_code in (404, 410):
            return [], ''
        raise
    if catalog_path.startswith('/stars/'):
        expected = urlsplit(url)
        actual = urlsplit(response.url)
        if actual.netloc != expected.netloc or actual.path.rstrip('/') != expected.path.rstrip('/'):
            raise ArchiveRedirectError('La web ha redirigido la ficha de Star a otro listado. No se muestran vídeos ajenos a esta ruta.')
    items = parse_listing_html(base, response.text)
    parser = PaginationParser(response.url, page)
    parser.feed(response.text)
    next_url = parser.next_url or parser.numbered_url
    if catalog_path.startswith('/stars/') and next_url:
        candidate = urlsplit(next_url)
        expected_path = catalog_path.rstrip('/') + '/page/{}/'.format(page + 1)
        if candidate.netloc != urlsplit(url).netloc or candidate.path.rstrip('/') != expected_path.rstrip('/'):
            next_url = ''
    if not next_url and (parser.load_more or catalog_path or search) and items:
        parts = urlsplit(url if catalog_path or search else response.url)
        path = re.sub(r'/page/\d+/?$', '/', parts.path).rstrip('/')
        path += '/page/{}/'.format(page + 1)
        params = [(k, v) for k, v in parse_qsl(parts.query) if k != 'paged']
        next_url = urlunsplit((parts.scheme, parts.netloc, path, urlencode(params), ''))
    if search and next_url:
        # Some themes omit the search term from their pagination anchors.
        parts = urlsplit(next_url)
        params = [(k, v) for k, v in parse_qsl(parts.query) if k != 's']
        params.append(('s', search))
        next_url = urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(params), ''))
    return items, next_url if items else ''


def extract_playable(page_url: str, html: str = "") -> dict:
    """Find a playable URL on a VidMov single page: youtube/vimeo/mp4/m3u8/iframe."""
    if not html:
        html = _get(page_url).text

    # JSON-LD VideoObject
    for m in re.finditer(r'<script[^>]+type="application/ld\+json"[^>]*>([\s\S]*?)</script>', html, flags=re.I):
        try:
            data = json.loads(m.group(1))
        except Exception:
            continue
        if not isinstance(data, (list, dict)):
            continue
        nodes = data if isinstance(data, list) else data.get("@graph", [data])
        for node in nodes:
            if not isinstance(node, dict):
                continue
            content = node.get("contentUrl") or node.get("embedUrl")
            if content and _is_media(content):
                return {"url": content, "is_youtube": "youtu" in content}

    # common player data attributes / js vars
    patterns = [
        r'"(?:file|src|source|video_url|videourl)"\s*:\s*"(https?:[^"]+\.(?:mp4|m3u8)[^"]*)"',
        r"'(?:file|src|source)'\s*:\s*'(https?:[^']+\.(?:mp4|m3u8)[^']*)'",
        r'src="(https?:[^"]+\.(?:mp4|m3u8)[^"]*)"',
        r'https?://(?:www\.)?youtube\.com/embed/([A-Za-z0-9_-]{6,})',
        r'https?://youtu\.be/([A-Za-z0-9_-]{6,})',
        r'https?://(?:www\.)?youtube\.com/watch\?v=([A-Za-z0-9_-]{6,})',
        r'player\.vimeo\.com/video/(\d+)',
        r'<iframe[^>]+src="(https?://[^"]+)"',
    ]
    for pat in patterns:
        m = re.search(pat, html, flags=re.I)
        if not m:
            continue
        g = m.group(1)
        if "youtube" in pat or "youtu" in pat:
            vid = g if "http" not in g else None
            if vid and "http" not in g:
                return {"url": f"plugin://plugin.video.youtube/play/?video_id={g}", "is_youtube": True}
            if "youtu" in g:
                vid = re.search(r"([A-Za-z0-9_-]{6,})$", g.split("?")[0])
                if vid:
                    return {"url": f"plugin://plugin.video.youtube/play/?video_id={vid.group(1)}", "is_youtube": True}
        if "vimeo" in pat:
            return {"url": f"https://player.vimeo.com/video/{g}", "is_youtube": False}
        if _is_media(g) or g.startswith("http"):
            return {"url": g.replace("\\/", "/"), "is_youtube": False}

    return {"url": "", "is_youtube": False}


def _is_media(url: str) -> bool:
    u = url.lower()
    return any(x in u for x in (".mp4", ".m3u8", "youtube", "youtu.be", "vimeo", "dailymotion"))
