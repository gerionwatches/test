"""Bounded local record of video pages whose playback actually started."""
import hashlib
import sqlite3
import time
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

DATABASE = None
KEYS = None
LIMIT = 10000


def configure(profile):
    global DATABASE, KEYS
    DATABASE = Path(profile) / 'played.sqlite'
    KEYS = None


def key(url):
    parts = urlsplit(url)
    normalized = urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path.rstrip('/'), parts.query, ''))
    return hashlib.sha256(normalized.encode('utf-8')).digest()


def connect():
    DATABASE.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(DATABASE), timeout=1)
    db.execute('CREATE TABLE IF NOT EXISTS played (id BLOB PRIMARY KEY, started REAL NOT NULL)')
    return db


def contains(url):
    global KEYS
    if DATABASE is None:
        return False
    if KEYS is None:
        KEYS = set()
        if DATABASE.exists():
            try:
                with connect() as db:
                    KEYS = {row[0] for row in db.execute('SELECT id FROM played')}
                db.close()
            except (OSError, sqlite3.Error):
                pass
    return key(url) in KEYS


def record(url):
    global KEYS
    if DATABASE is None:
        return False
    try:
        with connect() as db:
            db.execute('INSERT OR REPLACE INTO played VALUES (?, ?)', (key(url), time.time()))
            db.execute('DELETE FROM played WHERE id IN (SELECT id FROM played ORDER BY started DESC LIMIT -1 OFFSET ?)', (LIMIT,))
        db.close()
        KEYS = None
        return True
    except (OSError, sqlite3.Error):
        return False


def clear():
    global KEYS
    if DATABASE is not None and DATABASE.exists():
        with connect() as db:
            db.execute('DELETE FROM played')
        db.execute('VACUUM')
        db.close()
    KEYS = set()


def observe(expected):
    if DATABASE is None:
        return None
    import xbmc
    class Observer(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.started = False
            self.failed = False
            self.opening = False

        def onPlayBackStarted(self):
            self.opening = True

        def onPlayBackStopped(self):
            if self.opening and not self.started:
                self.failed = True

        def onPlayBackEnded(self):
            if self.opening and not self.started:
                self.failed = True

        def onAVStarted(self):
            try:
                actual = self.getPlayingFile().split('|', 1)[0]
                if self.isPlayingVideo() and (expected.startswith('plugin://') or actual == expected.split('|', 1)[0]):
                    self.started = True
            except RuntimeError:
                pass

        def onPlayBackError(self):
            self.failed = True

    return Observer()


def wait_for_start(observer, page_url, timeout=90):
    if observer is None:
        return False
    import xbmc
    monitor = xbmc.Monitor()
    deadline = time.monotonic() + timeout
    while not observer.started and not observer.failed and time.monotonic() < deadline:
        if monitor.waitForAbort(0.2):
            return False
    if observer.started:
        return record(page_url)
    return False
