# -*- coding: utf-8 -*-
"""VidMov mirror selection and player configuration (no JavaScript execution)."""
import base64
import binascii
import json
import time
import re
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from html import unescape
from html.parser import HTMLParser
from urllib.parse import parse_qs, unquote_to_bytes, urlencode, urljoin, urlsplit

from . import vidmov


class PlaybackError(Exception):
    pass


class PageParser(HTMLParser):
    def __init__(self, page_url):
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.mirrors = []
        self.sources = []
        self.frames = []
        self.player_frames = []
        self.player_depth = 0
        self.anchor = None
        self.seen = set()
        self.inline_data_scripts = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get('class') or '').split()
        if tag == 'script':
            src = attrs.get('src') or ''
            if src.lower().startswith('data:'):
                self.inline_data_scripts.append(src)
        if tag == 'div':
            if self.player_depth:
                self.player_depth += 1
            elif 'beeteam368-player' in classes:
                self.player_depth = 1
        if tag == 'a' and 'btn-p-group-item' in classes:
            url = urljoin(self.page_url, attrs.get('href') or '')
            if urlsplit(url).scheme in ('http', 'https'):
                self.anchor = {'url': url, 'title': ''}
        if tag in ('video', 'source', 'iframe'):
            src = attrs.get('src') or attrs.get('data-src') or ''
            if src:
                url = urljoin(self.page_url, src)
                if tag == 'iframe':
                    self.frames.append(url)
                    if self.player_depth:
                        self.player_frames.append(url)
                else:
                    self.sources.append(url)

    def handle_data(self, data):
        if self.anchor is not None:
            self.anchor['title'] += data

    def handle_endtag(self, tag):
        if tag == 'div' and self.player_depth:
            self.player_depth -= 1
        if tag == 'a' and self.anchor is not None:
            item, self.anchor = self.anchor, None
            if item['url'] not in self.seen:
                self.seen.add(item['url'])
                item['title'] = ' '.join(item['title'].split()) or 'Mirror'
                self.mirrors.append(item)


def parse_page(page_url, html):
    parser = PageParser(page_url)
    parser.feed(html)
    return parser


def load_page(url, referer=None):
    response = vidmov.SESSION.get(
        url, headers={'Referer': referer} if referer else {}, timeout=vidmov.TIMEOUT)
    response.raise_for_status()
    return response.url, response.text


def player_configs(html):
    documents = [html]
    # Cache/optimisation plugins can move inline JS into data URLs. Decode only
    # the script text; never execute it or fetch external script resources.
    for src in parse_page('', html).inline_data_scripts:
        if len(src) > 2 * 1024 * 1024:
            continue
        header, comma, payload = src.partition(',')
        if not comma:
            continue
        try:
            raw = unquote_to_bytes(payload)
            if 'base64' in header.lower().split(';')[1:]:
                raw = base64.b64decode(re.sub(rb'\s+', b'', raw), validate=True)
            documents.append(raw.decode('utf-8-sig'))
        except (ValueError, UnicodeError, binascii.Error):
            continue
    for document in documents:
        yield from _configs_in_script(document)


def _configs_in_script(html):
    # raw_decode handles nested objects, escaped iframe HTML and braces in strings.
    for match in re.finditer(r'\.beeteam368_(?:pro_)?player\s*\(\s*', html):
        try:
            value, _ = json.JSONDecoder().raw_decode(html[match.end():])
        except ValueError:
            continue
        if isinstance(value, dict):
            yield value


def _embedded_url(value, page_url):
    if not isinstance(value, str):
        return ''
    value = unescape(value).strip().replace('\\/', '/')
    if '<' in value:
        parsed = parse_page(page_url, value)
        values = parsed.frames or parsed.sources
        return values[0] if values else ''
    url = urljoin(page_url, value) if value else ''
    return url if urlsplit(url).scheme in ('http', 'https') else ''


def extract_source(page_url, html):
    configs = list(player_configs(html))
    if configs:
        # The first player is the main one. Never fall through to preview/ad URLs.
        config = configs[0]
        if config.get('media_protect'):
            raise PlaybackError('El sitio indica que este vídeo requiere acceso autorizado.')
        url = _embedded_url(config.get('video_url'), page_url)
        if url:
            return url
        for source in config.get('media_sources') or []:
            if isinstance(source, dict):
                url = _embedded_url(source.get('source_file') or source.get('source_url'), page_url)
                if url:
                    return url
        raise PlaybackError('La configuración del reproductor no contiene una URL de vídeo utilizable.')

    parsed = parse_page(page_url, html)
    candidates = parsed.player_frames or parsed.sources or parsed.frames
    if candidates:
        return candidates[0]
    # JSON-LD and conventional file/source fields, retained for older pages.
    media = vidmov.extract_playable(page_url, html=html or ' ')
    return media.get('url') or ''


def is_direct(url):
    return urlsplit(url.split('|', 1)[0]).path.lower().endswith(
        ('.mp4', '.m3u8', '.webm', '.m4v', '.mov', '.mp3', '.ogg', '.ogv'))


def youtube_url(url):
    parsed = urlsplit(url)
    host = (parsed.hostname or '').lower()
    video_id = ''
    if host == 'youtu.be':
        video_id = parsed.path.strip('/').split('/')[0]
    elif host in ('youtube.com', 'www.youtube.com', 'm.youtube.com',
                   'youtube-nocookie.com', 'www.youtube-nocookie.com'):
        video_id = parse_qs(parsed.query).get('v', [''])[0]
        if not video_id and parsed.path.startswith(('/embed/', '/shorts/')):
            video_id = parsed.path.split('/')[2]
    if video_id and re.fullmatch(r'[A-Za-z0-9_-]{6,}', video_id):
        return 'plugin://plugin.video.youtube/play/?' + urlencode({'video_id': video_id})
    return ''


def register_optional_resolvers(resolver):
    """Register the installed SMR extension using Kodi's portable path API."""
    try:
        import xbmcvfs
        extension_path = 'special://home/addons/script.module.resolveurl.xxx/resources/plugins/'
        if not xbmcvfs.exists(extension_path):
            return False
        path = xbmcvfs.translatePath(extension_path)
        registered = getattr(resolver, 'PLUGIN_DIRS', [])
        if not isinstance(registered, (list, tuple)) or path not in registered:
            resolver.add_plugin_dirs(path)
        return True
    except Exception as exc:
        # An absent or broken optional extension must not block normal hosts.
        try:
            import xbmc
            xbmc.log('VidMov optional resolver registration failed: ' +
                     type(exc).__name__, xbmc.LOGWARNING)
        except ImportError:
            pass
        return False


def source_support(url, referer, context=None):
    """Check installed resolvers only; never resolve or play a stream here."""
    host = urlsplit(url).hostname or ''
    if not url:
        return 'Sin comprobar', host
    if youtube_url(url) or url.startswith('plugin://plugin.video.youtube/'):
        import xbmc
        return ('YouTube disponible' if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)')
                else 'Falta YouTube'), 'YouTube'
    if is_direct(url):
        return 'Enlace directo', host
    if urlsplit(url).scheme not in ('http', 'https'):
        return 'Sin comprobar', host
    context = {} if context is None else context
    try:
        if 'resolver' not in context:
            try:
                import resolveurl
            except ImportError:
                context['resolver'] = None
            else:
                register_optional_resolvers(resolveurl)
                context['resolver'] = resolveurl
        resolver = context['resolver']
        if resolver is None:
            return 'Falta ResolveURL', host
        checks = context.setdefault('checks', {})
        key = (url, referer)
        if key not in checks:
            hosted = resolver.HostedMediaFile(url=url + '$$' + referer,
                                             include_universal=False, include_popups=False)
            checks[key] = bool(hosted.valid_url())
        return ('Conector disponible' if checks[key] else 'Sin conector directo'), host
    except Exception:
        return 'Sin comprobar', host


def _probe_source(url, original_url, original_html, headers, cookies):
    """Worker: HTTP and text parsing only. Never call Kodi/ResolveURL here."""
    received_cookies = None
    try:
        if url == original_url:
            page_url, html = original_url, original_html
        elif is_direct(url) or youtube_url(url):
            return {'source': url, 'referer': original_url, 'created': time.monotonic()}
        else:
            # No shared requests.Session: each worker owns its cookies/connections.
            with vidmov.requests.Session() as session:
                session.headers.update(headers)
                session.cookies.update(cookies)
                response = session.get(url, headers={'Referer': original_url}, timeout=(5, 8))
                response.raise_for_status()
                page_url, html = response.url, response.text
                received_cookies = session.cookies.copy()
        source = extract_source(page_url, html)
        if source:
            return {'source': source, 'referer': page_url, 'created': time.monotonic(), 'cookies': received_cookies}
    except Exception:
        pass
    return None


def probe_mirrors(mirrors, original_url, original_html, cancelled, on_result):
    """At most three HTTP requests at once; callbacks always run on the caller."""
    if cancelled():
        return
    headers = dict(vidmov.SESSION.headers)
    cookies = vidmov.SESSION.cookies.copy()
    grouped = {}
    for index, item in enumerate(mirrors):
        grouped.setdefault(item['url'], []).append(index)
    remote = {}
    for url, indexes in grouped.items():
        if url == original_url or is_direct(url) or youtube_url(url):
            if cancelled():
                return
            entry = _probe_source(url, original_url, original_html, headers, cookies)
            for index in indexes:
                on_result(index, entry)
        else:
            remote[url] = indexes
    if not remote or cancelled():
        return
    pool = ThreadPoolExecutor(max_workers=min(3, len(remote)))
    pending = {}
    try:
        for url, indexes in remote.items():
            pending[pool.submit(_probe_source, url, original_url, original_html, headers, cookies)] = indexes
        while pending:
            if cancelled():
                return
            done, _ = wait(pending, timeout=0.1, return_when=FIRST_COMPLETED)
            for future in done:
                if cancelled():
                    return
                indexes = pending.pop(future)
                try:
                    entry = future.result()
                except Exception:
                    entry = None
                for index in indexes:
                    on_result(index, entry)
    finally:
        for future in pending:
            future.cancel()
        # Running HTTP requests finish on their own timeout, without touching UI/cache.
        pool.shutdown(wait=False)


def inspect_mirror(mirror_url, original_url, original_html, cache=None):
    try:
        if mirror_url == original_url:
            page_url, html = original_url, original_html
        elif is_direct(mirror_url) or youtube_url(mirror_url):
            if cache is not None:
                cache[mirror_url] = {"source": mirror_url, "referer": original_url, "created": time.monotonic()}
            return source_support(mirror_url, original_url)
        else:
            page_url, html = load_page(mirror_url, original_url)
        source = extract_source(page_url, html)
        if source and cache is not None:
            cache[mirror_url] = {"source": source, "referer": page_url, "created": time.monotonic()}
        return source_support(source, page_url)
    except Exception:
        # A failed page fetch is not evidence that a connector is absent.
        return 'Sin comprobar', ''


def resolve_source(url, referer, resolver=None, depth=0, seen=None):
    """Resolve host pages; only hand Kodi a media URL or a YouTube plugin URL."""
    seen = set() if seen is None else seen
    if not url or url in seen or depth > 3:
        raise PlaybackError('No se encontró el vídeo del mirror (enlace vacío o bucle de iframes).')
    seen.add(url)
    if url.startswith('plugin://plugin.video.youtube/'):
        return url
    youtube = youtube_url(url)
    if youtube:
        return youtube
    if urlsplit(url).scheme not in ('http', 'https'):
        raise PlaybackError('El mirror usa un tipo de enlace no compatible.')
    if is_direct(url):
        return url if '|' in url else url + '|' + urlencode({
            'User-Agent': vidmov.HEADERS['User-Agent'], 'Referer': referer})

    if resolver is None:
        try:
            import resolveurl as resolver
        except ImportError:
            raise PlaybackError('Para reproducir mirrors externos, instala o activa ResolveURL '
                                '(script.module.resolveurl) y vuelve a intentarlo.')
        register_optional_resolvers(resolver)
    hosted = resolver.HostedMediaFile(url=url + '$$' + referer)
    if hosted.valid_url():
        resolved = hosted.resolve()
        if not resolved or resolved.split('|', 1)[0] == url.split('|', 1)[0]:
            raise PlaybackError('El servidor no devolvió un vídeo reproducible. Prueba otro mirror.')
        return resolved

    # Some mirrors are wrapper pages around a host understood by ResolveURL.
    final_url, html = load_page(url, referer)
    if final_url != url and (youtube_url(final_url) or is_direct(final_url)):
        return resolve_source(final_url, url, resolver, depth + 1, seen)
    if final_url != url:
        hosted = resolver.HostedMediaFile(url=final_url + '$$' + url)
        if hosted.valid_url():
            resolved = hosted.resolve()
            if resolved and resolved.split('|', 1)[0] != final_url.split('|', 1)[0]:
                return resolved
            raise PlaybackError('El servidor no devolvió un vídeo reproducible.')
    nested = extract_source(final_url, html)
    if nested:
        return resolve_source(nested, final_url, resolver, depth + 1, seen)
    raise PlaybackError('Sin conector compatible para este servidor y sin un enlace alternativo en la página. '
                        'Actualiza ResolveURL o selecciona otro mirror.')
