# -*- coding: utf-8 -*-
"""Parser for WordPress + VidMov (BeeTeam368) public HTML / REST."""
from __future__ import annotations

import json
import hashlib
from html.parser import HTMLParser
import re
from html import unescape
from urllib.parse import urljoin, urlparse, quote_plus, urlencode, parse_qsl, urlsplit, urlunsplit

import requests

HEADERS = {
    "User-Agent": "VidMovTubeKodi/1.0 (didactic; SFW)",
    "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)
TIMEOUT = 20

CPT_CANDIDATES = ("vidmov_video", "video", "posts")
TAX_CANDIDATES = ("vidmov_video_category", "video-category", "video_category", "categories")


def _get(url: str) -> requests.Response:
    r = SESSION.get(url, timeout=TIMEOUT)
    r.raise_for_status()
    return r


def normalize_base(url: str) -> str:
    url = (url or "").strip().rstrip("/")
    if not url:
        return "https://vm.beeteam368.net"
    if not url.startswith("http"):
        url = "https://" + url
    return url


def abs_url(base: str, href: str) -> str:
    if not href:
        return ""
    return urljoin(base + "/", href)


def discover_cpt(base: str) -> str:
    try:
        types = _get(base + "/wp-json/wp/v2/types").json()
        if isinstance(types, dict):
            for key in CPT_CANDIDATES:
                if key in types:
                    return key
            for key, meta in types.items():
                rest = (meta or {}).get("rest_base") or key
                if "video" in key or "video" in rest:
                    return rest
    except Exception:
        pass
    return "vidmov_video"


def list_via_rest(base: str, cpt: str, page: int = 1, search: str = "", tax: str = "", term: int = 0, paginated=False):
    endpoint = f"{base}/wp-json/wp/v2/{cpt}"
    params = f"?per_page=20&page={page}&_embed=1"
    if search:
        params += "&search=" + quote_plus(search)
    if tax and term:
        params += f"&{tax}={term}"
    response = _get(endpoint + params)
    data = response.json()
    items = []
    if not isinstance(data, list):
        raise ValueError("La API no devolvió un catálogo")
    for post in data:
        title = unescape(post.get("title", {}).get("rendered") or post.get("slug") or "Video")
        title = re.sub(r"<[^>]+>", "", title)
        link = post.get("link") or ""
        thumb = ""
        emb = post.get("_embedded") or {}
        media = emb.get("wp:featuredmedia") or []
        if media:
            thumb = media[0].get("source_url") or ""
        items.append(
            {
                "title": title,
                "url": link,
                "thumb": thumb,
                "plot": re.sub(r"<[^>]+>", "", unescape(post.get("excerpt", {}).get("rendered") or "")),
                "id": post.get("id"),
            }
        )
    if paginated:
        total = response.headers.get('X-WP-TotalPages')
        has_next = page < int(total) if total and total.isdigit() else len(items) == 20
        return items, bool(items) and has_next
    return items



def list_categories_rest(base: str, page=1, tax='', paginated=False):
    # Discover the taxonomy once; subsequent pages must use the same endpoint.
    candidates = (tax,) if tax else TAX_CANDIDATES
    for candidate in candidates:
        try:
            response = _get(f"{base}/wp-json/wp/v2/{candidate}?per_page=50&page={page}&orderby=name&order=asc")
            data = response.json()
            if not isinstance(data, list):
                raise ValueError("La API no devolvió una lista de categorías")
            if not data and not tax:
                continue
            out = []
            for term in data:
                out.append({
                    "title": unescape(term.get("name") or term.get("slug") or "Categoría"),
                    "tax": candidate,
                    "id": term.get("id"),
                    "slug": term.get("slug"),
                    "count": term.get("count") or 0,
                })
            total = response.headers.get('X-WP-TotalPages')
            has_next = page < int(total) if total and total.isdigit() else len(out) == 50
            return (out, bool(out) and has_next, candidate) if paginated else out
        except requests.exceptions.HTTPError as exc:
            if tax:
                if page > 1 and exc.response is not None and exc.response.status_code == 400:
                    try:
                        code = exc.response.json().get('code')
                    except (ValueError, AttributeError):
                        code = None
                    if code == 'rest_post_invalid_page_number':
                        return ([], False, tax) if paginated else []
                raise
        except Exception:
            if tax:
                raise
    return ([], False, '') if paginated else []


def category_signature(items):
    keys = sorted(str(item.get('tax')) + ':' + str(item.get('id')) for item in items)
    return hashlib.sha256('\n'.join(keys).encode('utf-8')).hexdigest()


def parse_listing_html(base: str, html: str):
    """Fallback: VidMov cards (article.vidmov_video / post-listing-title)."""
    items = []
    seen = set()
    # article blocks
    for m in re.finditer(
        r'<article[^>]*class="[^"]*vidmov_video[^"]*"[\s\S]{0,2500}?</article>',
        html,
        flags=re.I,
    ):
        block = m.group(0)
        href = ""
        title = ""
        tm = re.search(r'class="post-listing-title"[^>]*href="([^"]+)"[^>]*>([^<]+)', block)
        if not tm:
            tm = re.search(r'<h3[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([^<]+)', block)
        if tm:
            href, title = tm.group(1), unescape(tm.group(2)).strip()
        if not href:
            am = re.search(r'href="([^"]+/video/[^"]+)"', block)
            if am:
                href = am.group(1)
        img = ""
        im = re.search(r'<img[^>]+src="([^"]+)"', block)
        if im:
            img = im.group(1)
        href = abs_url(base, href)
        if href and href not in seen:
            seen.add(href)
            items.append({"title": title or href.rsplit("/", 2)[-2], "url": href, "thumb": abs_url(base, img), "plot": ""})

    if items:
        return items

    # generic /video/ links
    for m in re.finditer(r'href="([^"]+/video/([^/"#?]+)/?)"[^>]*>([^<]{3,160})', html):
        href = abs_url(base, m.group(1))
        if href in seen:
            continue
        seen.add(href)
        items.append({"title": unescape(m.group(3)).strip(), "url": href, "thumb": "", "plot": ""})
    return items


def list_via_html(base: str, path: str = "/"):
    html = _get(abs_url(base, path)).text
    return parse_listing_html(base, html)


def listing_signature(items):
    urls = sorted(set(item.get('url', '') for item in items))
    return hashlib.sha256('\n'.join(urls).encode('utf-8')).hexdigest()


class PaginationParser(HTMLParser):
    def __init__(self, current_url, page):
        super().__init__(convert_charrefs=True)
        self.current_url = current_url
        self.page = page
        self.next_url = ''
        self.numbered_url = ''
        self.load_more = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = (attrs.get('class') or '').split()
        if any('loadmore' in c or 'load-more' in c for c in classes):
            self.load_more = True
        href = attrs.get('href')
        if tag not in ('a', 'link') or not href:
            return
        target = urljoin(self.current_url, href)
        parts = urlsplit(target)
        if parts.scheme not in ('http', 'https') or parts.netloc != urlsplit(self.current_url).netloc:
            return
        if target == self.current_url or href.startswith('#'):
            return
        if 'next' in (attrs.get('rel') or '').split() or ('next' in classes and 'page-numbers' in classes):
            self.next_url = target
        if 'page-numbers' in classes:
            match = re.search(r'/page/(\d+)/?', parts.path)
            number = (match.group(1) if match else dict(parse_qsl(parts.query)).get('paged', ''))
            if number == str(self.page + 1):
                self.numbered_url = target


def html_listing_page(base, page=1, search='', tax='', term='', listing_url='', catalog_path=''):
    query = {}
    if search:
        query['s'] = search
    if tax and term:
        query[tax] = term
    root_path = '/' + catalog_path.strip('/') + '/' if catalog_path.strip('/') else '/'
    path = root_path if page == 1 else root_path + 'page/{}/'.format(page)
    url = listing_url or base.rstrip('/') + path + ('?' + urlencode(query) if query else '')
    try:
        response = _get(url)
    except requests.exceptions.HTTPError as exc:
        if page > 1 and exc.response is not None and exc.response.status_code in (404, 410):
            return [], ''
        raise
    items = parse_listing_html(base, response.text)
    parser = PaginationParser(response.url, page)
    parser.feed(response.text)
    next_url = parser.next_url or parser.numbered_url
    if not next_url and (parser.load_more or catalog_path) and items:
        parts = urlsplit(url if catalog_path else response.url)
        path = re.sub(r'/page/\d+/?$', '/', parts.path).rstrip('/')
        path += '/page/{}/'.format(page + 1)
        params = [(k, v) for k, v in parse_qsl(parts.query) if k != 'paged']
        next_url = urlunsplit((parts.scheme, parts.netloc, path, urlencode(params), ''))
    return items, next_url if items else ''


def extract_playable(page_url: str, html: str = "") -> dict:
    """Find a playable URL on a VidMov single page: youtube/vimeo/mp4/m3u8/iframe."""
    if not html:
        html = _get(page_url).text

    # JSON-LD VideoObject
    for m in re.finditer(r'<script[^>]+type="application/ld\+json"[^>]*>([\s\S]*?)</script>', html, flags=re.I):
        try:
            data = json.loads(m.group(1))
        except Exception:
            continue
        if not isinstance(data, (list, dict)):
            continue
        nodes = data if isinstance(data, list) else data.get("@graph", [data])
        for node in nodes:
            if not isinstance(node, dict):
                continue
            content = node.get("contentUrl") or node.get("embedUrl")
            if content and _is_media(content):
                return {"url": content, "is_youtube": "youtu" in content}

    # common player data attributes / js vars
    patterns = [
        r'"(?:file|src|source|video_url|videourl)"\s*:\s*"(https?:[^"]+\.(?:mp4|m3u8)[^"]*)"',
        r"'(?:file|src|source)'\s*:\s*'(https?:[^']+\.(?:mp4|m3u8)[^']*)'",
        r'src="(https?:[^"]+\.(?:mp4|m3u8)[^"]*)"',
        r'https?://(?:www\.)?youtube\.com/embed/([A-Za-z0-9_-]{6,})',
        r'https?://youtu\.be/([A-Za-z0-9_-]{6,})',
        r'https?://(?:www\.)?youtube\.com/watch\?v=([A-Za-z0-9_-]{6,})',
        r'player\.vimeo\.com/video/(\d+)',
        r'<iframe[^>]+src="(https?://[^"]+)"',
    ]
    for pat in patterns:
        m = re.search(pat, html, flags=re.I)
        if not m:
            continue
        g = m.group(1)
        if "youtube" in pat or "youtu" in pat:
            vid = g if "http" not in g else None
            if vid and "http" not in g:
                return {"url": f"plugin://plugin.video.youtube/play/?video_id={g}", "is_youtube": True}
            if "youtu" in g:
                vid = re.search(r"([A-Za-z0-9_-]{6,})$", g.split("?")[0])
                if vid:
                    return {"url": f"plugin://plugin.video.youtube/play/?video_id={vid.group(1)}", "is_youtube": True}
        if "vimeo" in pat:
            return {"url": f"https://player.vimeo.com/video/{g}", "is_youtube": False}
        if _is_media(g) or g.startswith("http"):
            return {"url": g.replace("\\/", "/"), "is_youtube": False}

    return {"url": "", "is_youtube": False}


def _is_media(url: str) -> bool:
    u = url.lower()
    return any(x in u for x in (".mp4", ".m3u8", "youtube", "youtu.be", "vimeo", "dailymotion"))
