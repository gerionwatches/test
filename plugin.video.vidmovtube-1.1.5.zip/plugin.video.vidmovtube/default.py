# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
import requests
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import vidmov, player

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_PLUGIN = sys.argv[0]


def get_base() -> str:
    return vidmov.normalize_base(ADDON.getSetting("base_url") or "https://vm.beeteam368.net")


def plugin_url(**kwargs) -> str:
    return BASE_PLUGIN + "?" + urlencode({k: v for k, v in kwargs.items() if v is not None})


def add_dir(title, **params):
    url = plugin_url(**params)
    li = xbmcgui.ListItem(label=title)
    li.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def add_video(item: dict):
    li = xbmcgui.ListItem(label=item.get("title") or "Video")
    info = {"title": item.get("title"), "plot": item.get("plot") or ""}
    li.setInfo("video", info)
    art = {}
    if item.get("thumb"):
        art["thumb"] = art["poster"] = art["fanart"] = item["thumb"]
    li.setArt(art)
    li.setProperty("IsPlayable", "true")
    url = plugin_url(mode="play", url=item.get("url") or "")
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def end():
    xbmcplugin.endOfDirectory(HANDLE)


def mode_root():
    add_dir("Últimos vídeos", mode="latest", page="1")
    add_dir("Categorías", mode="categories")
    add_dir("Buscar", mode="search")
    add_dir("Ajustes (URL del sitio)", mode="settings")
    end()


def mode_latest(page: int = 1, search: str = "", tax: str = "", term: str = "",
                source: str = "", listing_url: str = "", previous: str = ""):
    base = get_base()
    catalog_path = ""
    if not search and not tax and source != "rest":
        catalog_path = (ADDON.getSetting("catalog_path") or "/category/english-sub-7/").strip()
    use_json = not catalog_path and source != "html" and ADDON.getSetting("use_wp_json") != "false"
    items, has_next, next_url = [], False, ""
    rest_loaded = False
    if use_json:
        try:
            cpt = vidmov.discover_cpt(base)
            items, has_next = vidmov.list_via_rest(
                base, cpt, page=page, search=search, tax=tax, term=int(term or 0), paginated=True)
            rest_loaded = True
            source = "rest"
        except Exception as exc:
            # A REST continuation must never switch back to the HTML homepage.
            if source == "rest":
                xbmcgui.Dialog().notification("VidMov Tube", "No se pudo cargar la siguiente página del catálogo.", xbmcgui.NOTIFICATION_ERROR)
                end()
                return
            xbmc.log("VidMov REST fallback: " + type(exc).__name__, xbmc.LOGWARNING)
    if not rest_loaded:
        source = "html"
        try:
            items, next_url = vidmov.html_listing_page(
                base, page=page, search=search, tax=tax, term=term, listing_url=listing_url, catalog_path=catalog_path)
            has_next = bool(next_url)
        except Exception as exc:
            xbmcgui.Dialog().notification("VidMov Tube", playback_error_message(exc, "cargar el catálogo"), xbmcgui.NOTIFICATION_ERROR)
            end()
            return
    signature = vidmov.listing_signature(items)
    if previous and signature == previous:
        xbmcgui.Dialog().notification("VidMov Tube", "El sitio ha devuelto la misma página; no hay nuevos vídeos.", xbmcgui.NOTIFICATION_INFO)
        end()
        return
    for it in items:
        add_video(it)
    if items and has_next:
        add_dir("Página siguiente", mode="latest", page=str(page + 1), search=search,
                tax=tax, term=term, source=source, listing_url=next_url, previous=signature)
    end()


def mode_categories(page: int = 1, tax: str = "", previous: str = ""):
    base = get_base()
    try:
        cats, has_next, selected_tax = vidmov.list_categories_rest(
            base, page=page, tax=tax, paginated=True)
    except Exception as exc:
        xbmcgui.Dialog().notification("VidMov Tube", playback_error_message(exc, "cargar las categorías"), xbmcgui.NOTIFICATION_ERROR)
        end()
        return
    signature = vidmov.category_signature(cats)
    if previous and signature == previous:
        xbmcgui.Dialog().notification("VidMov Tube", "El sitio ha devuelto las mismas categorías; no hay resultados nuevos.", xbmcgui.NOTIFICATION_INFO)
        end()
        return
    if not cats:
        message = "No se leyeron categorías vía REST; usa Últimos o Buscar" if page == 1 else "No hay más categorías."
        xbmcgui.Dialog().notification("VidMov Tube", message, xbmcgui.NOTIFICATION_INFO)
    for cat in cats:
        label = cat["title"]
        if cat.get("count"):
            label += f" ({cat['count']})"
        add_dir(label, mode="latest", page="1", tax=cat.get("tax") or "", term=str(cat.get("id") or ""))
    if cats and has_next:
        add_dir("Página siguiente", mode="categories", page=str(page + 1),
                tax=selected_tax, previous=signature)
    end()


def mode_search():
    kb = xbmc.Keyboard("", "Buscar en el tubo VidMov")
    kb.doModal()
    if not kb.isConfirmed():
        return
    q = kb.getText().strip()
    if q:
        mode_latest(page=1, search=q)


def playback_error_message(exc, stage):
    """Explain the failure without logging URLs, query tokens or cookies."""
    prefix = "Error al " + stage + ". "
    if isinstance(exc, requests.exceptions.HTTPError):
        response = exc.response
        code = response.status_code if response is not None else None
        reasons = {
            401: "El servidor requiere autenticación.",
            403: "El servidor ha denegado el acceso.",
            404: "No se encuentra la página. El enlace puede ser incorrecto o haber caducado.",
            410: "La página ya no está disponible.",
            429: "El servidor limita las peticiones. Espera antes de reintentarlo.",
        }
        reason = reasons.get(code, "El servidor devolvió un error.")
        return prefix + "HTTP " + str(code or "desconocido") + ": " + reason
    if isinstance(exc, requests.exceptions.SSLError):
        return prefix + "No se pudo verificar el certificado HTTPS del servidor."
    if isinstance(exc, requests.exceptions.Timeout):
        return prefix + "El servidor no respondió dentro del tiempo de espera."
    if isinstance(exc, requests.exceptions.ConnectionError):
        return prefix + "No se pudo conectar con el servidor."
    return prefix + "Fallo interno (" + type(exc).__name__ + "). Consulta el registro de Kodi."


def mode_play(page_url: str):
    if not page_url:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    stage = "cargar la ficha"
    try:
        page_url, html = player.load_page(page_url)
        stage = "leer la lista de mirrors"
        mirrors = player.parse_page(page_url, html).mirrors
        if mirrors:
            selected = xbmcgui.Dialog().select(
                "Selecciona un mirror", [item["title"] for item in mirrors])
            if selected < 0:
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
            selected_url = mirrors[selected]["url"]
            if selected_url != page_url:
                stage = "cargar el mirror seleccionado"
                page_url, html = player.load_page(selected_url, page_url)
        stage = "leer la configuración del reproductor"
        source = player.extract_source(page_url, html)
        if not source:
            raise player.PlaybackError(
                "Este mirror no expone una URL en el HTML ni en la configuración "
                "del reproductor. Prueba otro mirror.")
        stage = "resolver el servidor de vídeo"
        play = player.resolve_source(source, page_url)
        if play.startswith('plugin://plugin.video.youtube/') and not xbmc.getCondVisibility(
                'System.HasAddon(plugin.video.youtube)'):
            raise player.PlaybackError('Instala el complemento YouTube para reproducir este enlace.')
    except player.PlaybackError as exc:
        xbmcgui.Dialog().ok("VidMov Tube", str(exc))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    except Exception as exc:
        message = playback_error_message(exc, stage)
        xbmc.log("VidMov: " + message, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("VidMov Tube", message)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=play)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def mode_settings():
    ADDON.openSettings()


def router():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    mode = params.get("mode") or "root"
    if mode == "root":
        mode_root()
    elif mode == "latest":
        mode_latest(page=int(params.get("page") or 1), search=params.get("search") or "", tax=params.get("tax") or "", term=params.get("term") or "", source=params.get("source") or "", listing_url=params.get("listing_url") or "", previous=params.get("previous") or "")
    elif mode == "categories":
        mode_categories(page=int(params.get("page") or 1), tax=params.get("tax") or "", previous=params.get("previous") or "")
    elif mode == "search":
        mode_search()
    elif mode == "play":
        mode_play(params.get("url") or "")
    elif mode == "settings":
        mode_settings()
    else:
        mode_root()


if __name__ == "__main__":
    router()
